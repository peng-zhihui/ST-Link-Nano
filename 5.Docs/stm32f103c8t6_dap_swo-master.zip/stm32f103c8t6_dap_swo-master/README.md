# STM32F103C8T6_CMSIS-DAP_SWO
-----------------------------

基于x893的仓库[CMSIS-DAP](https://github.com/x893/CMSIS-DAP)

基于RadioOperator的仓库[STM32F103C8T6_CMSIS-DAP_SWO](https://github.com/RadioOperator/STM32F103C8T6_CMSIS-DAP_SWO):

1. 升级CMSIS-DAP版本至V2.0.0（HID模式，非WinUSB）；
2. 启用SWO_UART功能（USART1），无SWO_STREAM/SWO_MANCHESTER模式；
3. 改善了CDC功能（USART2）；
4. 增加了Cortex-M的软复位功能；
5. 添加了BluePill板支持，重新映射或取消映射（请参阅[文档](./Doc/Bluepill/Bluepill CMSIS-DAP Pin-config.txt)）；
6. 增加了STLINK_V2A, STLINK_V2B板支持（请参阅[原理图](./Doc/STLINK_V2A_V2B/Schematic(part) STLINK_V2A_V2B.jpg)）；
7. 次要变更，如LED处理、项目文件重新分组

## 引脚定义

BluePill重新映射的SWD端口如下:
![alt text](./Doc/Bluepill/1.SWD_Remapped.jpg) 

## 食用方法

1. 使用ST-LINK V2烧写[DAP固件](./Hex/F103-DAP-SWO-CDC-BLUEPILL-SWD_PA14PA13.hex)至蓝色板，则

   ```
   SWCLK->PA14
   SWDIO->PA13
   ```

2. 蓝色板的USB口通过USB线连接电脑，蓝色板的`GND-3.3V-SWCLK-SWDIO`四根线连接待烧录的STM32芯片的SWD接口；

3. keil工程里，魔术棒设置如下<br>![图片](./Doc/Bluepill/OptionsforTarget.png)

4. 提示IDCODE即说明制作成功！<br>![图片](./Doc/Bluepill/SWDIO.png)

5. 更改USB驱动类型，可以下载[UsbDriverTool](https://visualgdb.com/UsbDriverTool/)

   `注意：Hex文件夹中的文件名，命名规则为SWCLK-SWDIO.hex`
   
   若刷写[标准V2固件](./Bin/STLinkV2.J16.S4.bin)，则
   
   ```
   SWCLK->PB13
   SWDIO->PB14
   NRST->PB0
   ```
   
   若刷写[ST-LINK/V2-1/V2-A/V2-B固件](./Bin/STLinkV2.J28.M18.bin)，则
   
   ```
   SWCLK->PB13
   SWDIO->PB14
   NRST->PB0
   TXD->PA2
   RXD->PA3
   ```
   
   

## 问题与解决

### 提示找不到“RTL.h”

需要安装 Legacy support for Arm Cortex-M devices支持包，从[keil官网](https://www2.keil.com/mdk5/legacy)下载

![网站](./Doc/Keil MDKv5 Install MDKv4 Lagacy Support.JPG)

### 提示找不到"cmsis_compiler.h"

从Keil官网安装[CMSIS (Cortex Microcontroller Software Interface Standard)](https://www.keil.com/dd2/pack/#!#eula-container)，然后点击Keil魔术棒进入Options for target，选择C/C++，根据自己的安装目录设置Include Paths内容。比如笔者的是：

```
D:\Keil_v5\MDK\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Driver\Include
D:\Keil_v5\MDK\ARM\PACK\ARM\CMSIS\5.7.0\CMSIS\Include
```
### 提示找不到“USB_CM3.lib”

```
.\build\F103-DAP-SWO-CDC-BLUEPILL-SWD_PB8PB9.axf: error: L6002U: Could not open file C:\Keil\ARM\RV31\LIB\USB_CM3.lib: No such file or directory
```

在工程中，将自己电脑上的D:\Keil_v5\MDK\ARM\RV31\LIB\USB_CM3.lib复制到工程USB文件夹，在keil中删除原来的USB_CM3.lib，再将新的添加进去，大功告成！

